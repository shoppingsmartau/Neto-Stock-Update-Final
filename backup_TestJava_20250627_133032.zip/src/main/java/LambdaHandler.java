    import com.amazonaws.services.lambda.runtime.Context;
    import com.amazonaws.services.lambda.runtime.RequestHandler;
    import com.amazonaws.services.lambda.runtime.events.ScheduledEvent;

    import java.util.List;
    import org.json.JSONArray;
    import org.json.JSONObject;

    /**
     * The main AWS Lambda handler class. This class implements RequestHandler
     * to correctly receive events from AWS CloudWatch (EventBridge).
     *
     * This class is now a separate top-level class for better compatibility
     * with the AWS Lambda runtime's class loading mechanisms.
     */
    public class LambdaHandler implements RequestHandler<ScheduledEvent, Void> {

        // Add a public zero-argument constructor as required by AWS Lambda
        public LambdaHandler() {
            // Constructor for Lambda to instantiate the class
            System.out.println("LambdaHandler constructor invoked.");
        }

        @Override
        public Void handleRequest(ScheduledEvent event, Context context) {
            context.getLogger().log("Lambda function invoked by CloudWatch Event at: " + event.getTime());

            try {
                // Core logic from DropshipzoneAPIClient
                String token = DropshipzoneAPIClient.authenticate();
                if (token == null) {
                    context.getLogger().log("Failed to extract Dropshipzone token. Aborting execution.");
                    throw new RuntimeException("Authentication failed.");
                }

                context.getLogger().log("Token acquired successfully.");

                // In a Lambda environment, files in the deployment package are usually read-only.
                // If skus.csv is bundled, FileReader will look in the root of the JAR.
                // For robust solutions, consider S3 for storing skus.csv.
                List<String> skuList = DropshipzoneAPIClient.loadSkusFromCSV("skus.csv");
                if (skuList.isEmpty()) {
                    context.getLogger().log("No SKUs found in 'skus.csv' file. Aborting execution.");
                    return null;
                }

                context.getLogger().log("Loaded SKUs from CSV: " + skuList.size() + " SKUs.");

                String stockResponse = DropshipzoneAPIClient.fetchStock(token, skuList);

                context.getLogger().log("\n--- Combined Raw Stock Response from Dropshipzone ---");
                if (stockResponse.length() < 5000) {
                    context.getLogger().log(stockResponse);
                } else {
                    context.getLogger().log("Raw stock response is very large, not printing to console.");
                }

                JSONObject stockJson;
                try {
                    context.getLogger().log("Attempting to parse combined stock response into JSONObject...");
                    stockJson = new JSONObject(stockResponse);
                    context.getLogger().log("Successfully parsed combined stock response.");
                } catch (org.json.JSONException jsonE) {
                    context.getLogger().log("CRITICAL ERROR: Failed to parse combined stock response into JSONObject.");
                    context.getLogger().log("Raw response content that failed parsing: " + stockResponse);
                    jsonE.printStackTrace();
                    throw new RuntimeException("Failed to parse main stock JSON response.", jsonE);
                }

                context.getLogger().log("\n--- Parsed Stock Data ---");
                JSONArray resultArray = new JSONArray();
                if (stockJson.has("result") && stockJson.getJSONArray("result").length() > 0) {
                    resultArray = stockJson.getJSONArray("result");
                    context.getLogger().log("Total stock items fetched successfully from API: " + resultArray.length());
                    if (resultArray.length() < 50) {
                        for (Object item : resultArray) {
                            context.getLogger().log(new JSONObject(item.toString()).toString(2));
                        }
                    } else {
                        context.getLogger().log("Too many stock items to pretty print to console.");
                    }

                    // Temporary files in Lambda should be written to /tmp/
                    DropshipzoneAPIClient.saveToCSV(resultArray, skuList, "/tmp/stock_data.csv");
                    context.getLogger().log("Stock data successfully saved to '/tmp/stock_data.csv'. This file now contains all original SKUs.");
                } else {
                    context.getLogger().log("No stock data found in the 'result' field of the response. Saving with default quantities for all SKUs.");
                    DropshipzoneAPIClient.saveToCSV(new JSONArray(), skuList, "/tmp/stock_data.csv");
                }

                // loadSkuQuantitiesFromCSV already expects /tmp/
                List<String[]> skuData = DropshipzoneAPIClient.loadSkuQuantitiesFromCSV("stock_data.csv");
                if (skuData.isEmpty()) {
                    context.getLogger().log("No SKU quantities found in 'stock_data.csv' to update Neto. Exiting.");
                    return null;
                }

                context.getLogger().log("\n--- Updating Neto Items ---");
                for (String[] entry : skuData) {
                    String sku = entry[0];
                    int quantity = Integer.parseInt(entry[1]);
                    context.getLogger().log(String.format("Attempting to update SKU: %s with Quantity: %d%n", sku, quantity));
                    DropshipzoneAPIClient.updateNetoItem(sku, quantity);
                }

                context.getLogger().log("All SKUs processed for update in Neto.");

            } catch (Exception e) {
                context.getLogger().log("An unhandled error occurred during Lambda execution:");
                e.printStackTrace();
                throw new RuntimeException("Lambda execution failed: " + e.getMessage(), e);
            }
            return null;
        }
    }
    