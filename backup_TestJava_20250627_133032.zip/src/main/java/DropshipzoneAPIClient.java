import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.json.JSONObject;
import org.json.JSONArray;

/**
 * A Java client for interacting with the Dropshipzone API to fetch stock data
 * and update item quantities in Neto.
 *
 * This class contains the core logic (API interactions, CSV handling)
 * and is designed to be called by the LambdaHandler class.
 *
 * Requirements:
 * - A 'skus.csv' file placed in 'src/main/resources' in the Maven project
 * so it's bundled correctly in the JAR and accessible as a resource.
 * - The 'org.json' library must be included in the project dependencies.
 */
public class DropshipzoneAPIClient {

    // Define a batch size for API requests to handle potential API limits
    private static final int SKU_BATCH_SIZE = 40; // Based on observed behavior, can be adjusted

    /**
     * Authenticates with the Dropshipzone API using predefined credentials.
     * Credentials are retrieved from environment variables.
     *
     * @return The JWT token string if authentication is successful, otherwise null.
     * @throws IOException If an I/O error occurs during the HTTP request.
     */
    protected static String authenticate() throws IOException {
        String authUrl = "https://api.dropshipzone.com.au/auth";

        // Retrieve credentials from environment variables
        String email = System.getenv("DROPSHIPZONE_EMAIL");
        String password = System.getenv("DROPSHIPZONE_PASSWORD");

        if (email == null || password == null || email.isEmpty() || password.isEmpty()) {
            System.err.println("Error: Dropshipzone credentials (DROPSHIPZONE_EMAIL, DROPSHIPZONE_PASSWORD) not set as environment variables.");
            return null;
        }

        JSONObject jsonInput = new JSONObject()
                .put("email", email)
                .put("password", password);

        HttpURLConnection authConn = (HttpURLConnection) new URL(authUrl).openConnection();
        authConn.setRequestMethod("POST");
        authConn.setRequestProperty("Content-Type", "application/json");
        authConn.setDoOutput(true);

        try (OutputStream os = authConn.getOutputStream()) {
            os.write(jsonInput.toString().getBytes(StandardCharsets.UTF_8));
        }

        int responseCode = authConn.getResponseCode();
        if (responseCode != 200) {
            System.err.println("Authentication failed with response code: " + responseCode);
            try (BufferedReader errorReader = new BufferedReader(
                    new InputStreamReader(authConn.getErrorStream(), StandardCharsets.UTF_8))) {
                StringBuilder errorResponse = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorResponse.append(line.trim());
                }
                System.err.println("Authentication Error Details: " + errorResponse.toString());
            }
            return null;
        }

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(authConn.getInputStream(), StandardCharsets.UTF_8))) {
            StringBuilder authResponse = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                authResponse.append(line.trim());
            }
            System.out.println("Dropshipzone Auth Raw Response: " + authResponse.toString());
            return extractToken(authResponse.toString());
        }
    }

    /**
     * Fetches stock data for a list of SKUs from the Dropshipzone API in batches.
     *
     * @param token The JWT token obtained from the authentication step.
     * @param allSkus A list of all SKU strings for which to fetch stock.
     * @return A single raw JSON response string containing aggregated stock data from all batches.
     * @throws IOException If an I/O error occurs during any HTTP request.
     */
    protected static String fetchStock(String token, List<String> allSkus) throws IOException {
        String stockUrl = "https://api.dropshipzone.com.au/stock";
        JSONArray combinedResultArray = new JSONArray();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        LocalDateTime endTime = LocalDateTime.now();
        LocalDateTime startTime = endTime.minusDays(7);

        for (int i = 0; i < allSkus.size(); i += SKU_BATCH_SIZE) {
            int endIndex = Math.min(i + SKU_BATCH_SIZE, allSkus.size());
            List<String> currentBatchSkus = allSkus.subList(i, endIndex);
            String skuString = String.join(",", currentBatchSkus);

            JSONObject requestPayload = new JSONObject()
                    .put("start_time", startTime.format(formatter))
                    .put("end_time", endTime.format(formatter))
                    .put("skus", skuString);

            System.out.println("\nDropshipzone Stock Request JSON Payload (Batch " + ((i / SKU_BATCH_SIZE) + 1) + "):");
            if (requestPayload.toString().length() < 2000) {
                System.out.println(requestPayload.toString(2));
            } else {
                System.out.println("Request payload for batch is very large, not printing to console.");
            }

            HttpURLConnection conn = (HttpURLConnection) new URL(stockUrl).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "jwt " + token);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(requestPayload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            System.out.println("Dropshipzone Stock API Response Code (Batch " + ((i / SKU_BATCH_SIZE) + 1) + "): " + responseCode);

            String responseBody;
            if (responseCode != 200) {
                try (BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = errorReader.readLine()) != null) {
                        errorResponse.append(line.trim());
                    }
                    responseBody = errorResponse.toString();
                    System.err.println("Dropshipzone Stock API Error Response (Batch " + ((i / SKU_BATCH_SIZE) + 1) + "):\n" + responseBody);
                }
                responseBody = "{\"result\":[]}"; // Return empty array on error for parsing
            } else {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line.trim());
                    }
                    responseBody = response.toString();
                }
            }
            System.out.println("Dropshipzone Stock Raw Response (Batch " + ((i / SKU_BATCH_SIZE) + 1) + "): " + responseBody);
            try {
                JSONObject batchResultJson = new JSONObject(responseBody);
                if (batchResultJson.has("result") && batchResultJson.getJSONArray("result").length() > 0) {
                    JSONArray batchResultArray = batchResultJson.getJSONArray("result");
                    for (int j = 0; j < batchResultArray.length(); j++) {
                        combinedResultArray.put(batchResultArray.getJSONObject(j));
                    }
                }
            } catch (org.json.JSONException jsonE) {
                System.err.println("ERROR: Failed to parse Dropshipzone Stock API response for batch " + ((i / SKU_BATCH_SIZE) + 1) + ".");
                System.err.println("Raw response content that failed parsing: " + responseBody);
                jsonE.printStackTrace();
            }
        }
        return new JSONObject().put("result", combinedResultArray).toString();
    }

    /**
     * Extracts the JWT token from a JSON string.
     *
     * @param json The JSON string containing the token.
     * @return The extracted token string, or null if not found.
     */
    protected static String extractToken(String json) {
        JSONObject obj;
        try {
            System.out.println("Attempting to extract token from JSON: " + json);
            obj = new JSONObject(json);
            System.out.println("Successfully extracted token JSON.");
        } catch (org.json.JSONException jsonE) {
            System.err.println("ERROR: Failed to parse JSON for token extraction.");
            System.err.println("Raw JSON content that failed parsing: " + json);
            jsonE.printStackTrace();
            return null;
        }
        return obj.optString("token", null);
    }

    /**
     * Loads a list of SKUs from a CSV file bundled within the JAR.
     * It assumes the SKUs are in the first column and skips the header row.
     *
     * @param filename The name of the CSV file.
     * @return A list of SKU strings.
     * @throws IOException If an I/O error occurs during file reading.
     */
    protected static List<String> loadSkusFromCSV(String filename) throws IOException {
        List<String> skus = new ArrayList<>();
        // Use getResourceAsStream to read the file from the classpath (i.e., from within the JAR)
        try (InputStream is = DropshipzoneAPIClient.class.getClassLoader().getResourceAsStream(filename);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

            if (is == null) {
                // This means the file was not found in the classpath
                throw new FileNotFoundException("Resource '" + filename + "' not found in classpath. Please ensure it's in src/main/resources.");
            }

            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                line = line.trim();
                if (!line.isEmpty()) {
                    skus.add(line.split(",")[0]);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading SKU file '" + filename + "': " + e.getMessage());
            throw e;
        }
        return skus;
    }

    /**
     * Saves a JSONArray of stock data to a CSV file.
     *
     * @param apiData The JSONArray containing stock information returned from the API.
     * @param allOriginalSkus The complete list of SKUs read from the input CSV.
     * @param filename The full path to the CSV file to write to (e.g., "/tmp/stock_data.csv").
     */
    protected static void saveToCSV(JSONArray apiData, List<String> allOriginalSkus, String filename) {
        Map<String, JSONObject> apiDataMap = new HashMap<>();
        for (Object obj : apiData) {
            JSONObject item;
            try {
                item = new JSONObject(obj.toString());
            } catch (org.json.JSONException jsonE) {
                System.err.println("ERROR: Failed to parse individual item from Dropshipzone API response JSONArray. Skipping this item.");
                System.err.println("Problematic item string: " + obj.toString());
                jsonE.printStackTrace();
                continue;
            }
            apiDataMap.put(item.optString("sku", "INVALID_SKU"), item);
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) { // Uses the provided full path (e.g., /tmp/...)
            writer.println("sku,is_in_stock,new_qty,status");

            for (String sku : allOriginalSkus) {
                JSONObject item = apiDataMap.get(sku);
                String is_in_stock = "false";
                int new_qty = 0;
                String status = "Not Found in API Response";

                if (item != null) {
                    is_in_stock = item.optString("is_in_stock", "false");
                    String newQtyStr = item.optString("new_qty", "0");
                    try {
                        new_qty = (int) Double.parseDouble(newQtyStr);
                        if (new_qty < 25) {
                            new_qty = 0;
                            status = "Quantity < 25, set to 0";
                        } else {
                            status = item.optString("status", "Found");
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Warning: Invalid number format for 'new_qty': '" + newQtyStr + "' for SKU " + sku + ". Defaulting to 0.");
                    }
                }

                String line = String.format("%s,%s,%d,%s",
                        sku,
                        is_in_stock,
                        new_qty,
                        status);
                writer.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error writing data to CSV file '" + filename + "': " + e.getMessage());
            e.printStackTrace();
        }
    }


    /**
     * Loads SKU and quantity data from a CSV file.
     * Assumes the file is located in the Lambda /tmp/ directory.
     *
     * @param filename The name of the CSV file in /tmp/ (e.g., "stock_data.csv").
     * @return A list of String arrays, where each array contains [SKU, Quantity].
     * @throws IOException If an I/O error occurs during file reading.
     */
    protected static List<String[]> loadSkuQuantitiesFromCSV(String filename) throws IOException {
        List<String[]> skuData = new ArrayList<>();
        // Now using /tmp/ explicitly for reading the written CSV
        try (BufferedReader reader = new BufferedReader(new FileReader("/tmp/" + filename))) {
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String sku = parts[0].trim();
                    String qtyStr = parts[2].trim();
                    try {
                        int qty = Integer.parseInt(qtyStr);
                        skuData.add(new String[]{sku, String.valueOf(qty)});
                    } catch (NumberFormatException e) {
                        System.err.println("Warning: Invalid quantity format for SKU '" + sku + "': '" + qtyStr + "'. Skipping this entry.");
                    }
                } else {
                    System.err.println("Warning: Skipping malformed CSV line (less than 3 columns): " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: CSV file '/tmp/" + filename + "' not found. Cannot load SKU quantities.");
            throw e;
        }
        return skuData;
    }

    /**
     * Updates the quantity of a specific item in Neto using the Neto API.
     * Credentials are retrieved from environment variables.
     *
     * @param sku The SKU of the item to update.
     * @param quantity The new quantity to set for the item.
     */
    protected static void updateNetoItem(String sku, int quantity) {
        String netoUrl = "https://www.shoppingsmart.com.au/do/WS/NetoAPI";

        // Retrieve Neto credentials from environment variables
        String netoUsername = System.getenv("NETOAPI_USERNAME");
        String netoKey = System.getenv("NETOAPI_KEY");

        if (netoUsername == null || netoKey == null || netoUsername.isEmpty() || netoKey.isEmpty()) {
            System.err.println("Error: Neto credentials (NETOAPI_USERNAME, NETOAPI_KEY) not set as environment variables. Skipping Neto update for SKU: " + sku);
            return;
        }

        JSONObject warehouseQuantity = new JSONObject()
                .put("WarehouseID", "2")
                .put("Quantity", String.valueOf(quantity))
                .put("Action", "Set");

        JSONObject item = new JSONObject()
                .put("SKU", sku)
                .put("WarehouseQuantity", warehouseQuantity);

        JSONObject payload = new JSONObject()
                .put("Item", item);

        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(netoUrl).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("NETOAPI_ACTION", "UpdateItem");
            conn.setRequestProperty("NETOAPI_USERNAME", netoUsername);
            conn.setRequestProperty("NETOAPI_KEY", netoKey);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();
            System.out.println("Neto API Response Code for SKU " + sku + ": " + responseCode);

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line.trim());
                }
                System.out.println("Neto API Raw Response for SKU " + sku + ": " + response.toString());

                try {
                    JSONObject netoResponseJson = new JSONObject(response.toString());
                    System.out.println("Neto API Parsed Response for SKU " + sku + ": " + netoResponseJson.toString(2));
                } catch (org.json.JSONException jsonE) {
                    System.err.println("ERROR: Failed to parse Neto API response for SKU " + sku + ".");
                    System.err.println("Raw Neto response content that failed parsing: " + response.toString());
                    jsonE.printStackTrace();
                }

            }

        } catch (IOException e) {
            System.err.println("Error calling Neto API for SKU " + sku + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}
